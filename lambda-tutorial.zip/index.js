exports.handler = async function(event) {
  console.log("Hello, world!");
  return "Hello, world!";
};
